/*!
 * Copyright (c) 2017-present Ghostery GmbH. All rights reserved.
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

import { hashHostnameBackward } from '../request.js';
import { toASCII } from '../punycode.js';
import { StaticDataView, sizeOfUint32Array, sizeOfUTF8 } from '../data-view.js';
import { binLookup, hasUnicode, HASH_INTERNAL_MULT } from '../utils.js';

function includesAny(sorted: Uint32Array | undefined, hashes: Uint32Array): boolean {
  if (sorted !== undefined) {
    for (const hash of hashes) {
      if (binLookup(sorted, hash)) {
        return true;
      }
    }
  }

  return false;
}

export class Domains {
  public static parse(
    value: string | Set<string>,
    { delimiter = ',', debug = false }: { delimiter?: string; debug?: boolean } = {},
  ): Domains | undefined {
    if (typeof value === 'string') {
      if (value.length === 0) {
        return undefined;
      }
    } else if (value.size === 0) {
      return undefined;
    }
    const parts = typeof value === 'string' ? value.split(delimiter) : value;
    for (const part of parts) {
      if (part.length === 0) {
        return undefined;
      }
    }

    const entities: number[] = [];
    const notEntities: number[] = [];
    const hostnames: number[] = [];
    const notHostnames: number[] = [];
    const rawParts: string[] = [];

    for (const rawHostname of parts) {
      let hostname = rawHostname;

      if (hasUnicode(hostname)) {
        hostname = toASCII(hostname);
      }

      const negation: boolean = hostname.charCodeAt(0) === 126; /* '~' */
      const entity: boolean =
        hostname.charCodeAt(hostname.length - 1) === 42 /* '*' */ &&
        hostname.charCodeAt(hostname.length - 2) === 46; /* '.' */

      const start: number = negation ? 1 : 0;
      const end: number = entity ? hostname.length - 2 : hostname.length;

      const hash = hashHostnameBackward(
        negation === true || entity === true ? hostname.slice(start, end) : hostname,
      );

      if (negation) {
        if (entity) {
          notEntities.push(hash);
        } else {
          notHostnames.push(hash);
        }
        if (debug) {
          rawParts.push(negation ? rawHostname : `~${rawHostname}`);
        }
      } else {
        if (entity) {
          entities.push(hash);
        } else {
          hostnames.push(hash);
        }
        if (debug) {
          rawParts.push(negation ? rawHostname.slice(1) : rawHostname);
        }
      }
    }

    return new Domains({
      entities: entities.length !== 0 ? new Uint32Array(entities).sort() : undefined,
      hostnames: hostnames.length !== 0 ? new Uint32Array(hostnames).sort() : undefined,
      notEntities: notEntities.length !== 0 ? new Uint32Array(notEntities).sort() : undefined,
      notHostnames: notHostnames.length !== 0 ? new Uint32Array(notHostnames).sort() : undefined,
      parts: debug === true ? rawParts.join(delimiter) : undefined,
    });
  }

  public static deserialize(buffer: StaticDataView): Domains {
    const optionalParts = buffer.getUint8();

    // The order of these fields should be the same as when we serialize them.
    return new Domains({
      entities: (optionalParts & 1) === 1 ? buffer.getUint32Array() : undefined,
      hostnames: (optionalParts & 2) === 2 ? buffer.getUint32Array() : undefined,
      notEntities: (optionalParts & 4) === 4 ? buffer.getUint32Array() : undefined,
      notHostnames: (optionalParts & 8) === 8 ? buffer.getUint32Array() : undefined,
      parts: (optionalParts & 16) === 16 ? buffer.getUTF8() : undefined,
    });
  }

  // hostnames
  public readonly entities: Uint32Array | undefined;
  public readonly hostnames: Uint32Array | undefined;

  // Exceptions
  public readonly notEntities: Uint32Array | undefined;
  public readonly notHostnames: Uint32Array | undefined;

  // Debug
  public readonly parts: string | undefined;

  constructor({
    entities,
    hostnames,
    notEntities,
    notHostnames,
    parts,
  }: {
    entities: Uint32Array | undefined;
    hostnames: Uint32Array | undefined;
    notEntities: Uint32Array | undefined;
    notHostnames: Uint32Array | undefined;
    parts: string | undefined;
  }) {
    // Hostname constraints
    this.entities = entities;
    this.hostnames = hostnames;

    // Hostname exceptions
    this.notEntities = notEntities;
    this.notHostnames = notHostnames;

    // Debug
    this.parts = parts;
  }

  public updateId(hash: number): number {
    const { hostnames, entities, notHostnames, notEntities } = this;

    if (hostnames !== undefined) {
      for (const hostname of hostnames) {
        hash = (hash * HASH_INTERNAL_MULT) ^ hostname;
      }
    }

    if (entities !== undefined) {
      for (const entity of entities) {
        hash = (hash * HASH_INTERNAL_MULT) ^ entity;
      }
    }

    if (notHostnames !== undefined) {
      for (const notHostname of notHostnames) {
        hash = (hash * HASH_INTERNAL_MULT) ^ notHostname;
      }
    }

    if (notEntities !== undefined) {
      for (const notEntity of notEntities) {
        hash = (hash * HASH_INTERNAL_MULT) ^ notEntity;
      }
    }

    return hash;
  }

  public serialize(buffer: StaticDataView): void {
    // Mandatory fields
    const index = buffer.getPos();
    buffer.pushUint8(0);

    // This bit-mask indicates which optional parts of the filter were serialized.
    let optionalParts = 0;

    if (this.entities !== undefined) {
      optionalParts |= 1;
      buffer.pushUint32Array(this.entities);
    }

    if (this.hostnames !== undefined) {
      optionalParts |= 2;
      buffer.pushUint32Array(this.hostnames);
    }

    if (this.notEntities !== undefined) {
      optionalParts |= 4;
      buffer.pushUint32Array(this.notEntities);
    }

    if (this.notHostnames !== undefined) {
      optionalParts |= 8;
      buffer.pushUint32Array(this.notHostnames);
    }

    if (this.parts !== undefined) {
      optionalParts |= 16;
      buffer.pushUTF8(this.parts);
    }

    buffer.setByte(index, optionalParts);
  }

  public getSerializedSize(): number {
    let estimate: number = 1; // optional parts (1 byte)

    if (this.entities !== undefined) {
      estimate += sizeOfUint32Array(this.entities);
    }

    if (this.hostnames !== undefined) {
      estimate += sizeOfUint32Array(this.hostnames);
    }

    if (this.notHostnames !== undefined) {
      estimate += sizeOfUint32Array(this.notHostnames);
    }

    if (this.notEntities !== undefined) {
      estimate += sizeOfUint32Array(this.notEntities);
    }

    if (this.parts !== undefined) {
      estimate += sizeOfUTF8(this.parts);
    }

    return estimate;
  }

  /**
   * Check if the list has at least one non-negated hostname or entity.
   *
   * Specific: `foo.com,~sub.foo.com` (applies on foo.com, except on sub.foo.com)
   * Generic:  `~foo.com` (applies everywhere, except on foo.com)
   */
  public isSpecific(): boolean {
    return this.hostnames !== undefined || this.entities !== undefined;
  }

  /**
   * Check if `hostname` matches a negated hostname or entity (e.g. `~foo.com`).
   */
  public matchNegated(hostnameHashes: Uint32Array, entityHashes: Uint32Array): boolean {
    return (
      includesAny(this.notHostnames, hostnameHashes) || includesAny(this.notEntities, entityHashes)
    );
  }

  /**
   * Check if `hostname` matches a non-negated hostname or entity (e.g. `foo.com`).
   */
  public matchPositive(hostnameHashes: Uint32Array, entityHashes: Uint32Array): boolean {
    return includesAny(this.hostnames, hostnameHashes) || includesAny(this.entities, entityHashes);
  }

  public match(hostnameHashes: Uint32Array, entityHashes: Uint32Array): boolean {
    // Check if `hostname` is blacklisted
    if (this.matchNegated(hostnameHashes, entityHashes)) {
      return false;
    }

    // Check if `hostname` is allowed. A generic list allows all other hostnames.
    if (this.isSpecific()) {
      return this.matchPositive(hostnameHashes, entityHashes);
    }

    return true;
  }
}
